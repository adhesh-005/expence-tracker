import logging
import traceback
from django.http import HttpResponse
from django.shortcuts import render

logger = logging.getLogger(__name__)

class ErrorLoggingMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            response = self.get_response(request)
            return response
        except Exception as e:
            logger.error(f"Unhandled exception: {str(e)}")
            logger.error(traceback.format_exc())
            
            # Only show debug info if explicitly requested
            if request.GET.get('DEBUG') == '1':
                return HttpResponse(f"Error: {str(e)}<br><pre>{traceback.format_exc()}</pre>", status=500)
            
            # Otherwise, render a friendly error page
            context = {'error': str(e)}
            return render(request, 'tracker/error.html', context, status=500)
