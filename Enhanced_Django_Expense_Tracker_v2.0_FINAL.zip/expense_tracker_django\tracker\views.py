import logging
import json
import csv
import traceback
import math
from datetime import datetime, timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.db.models import Sum, Count, Q, Avg
from django.http import HttpResponse, JsonResponse
from django.utils import timezone
from django.contrib import messages
from .models import Transaction, Budget, UserPreference, Loan
from .forms import UserRegistrationForm, TransactionForm, BudgetForm, UserPreferenceForm, LoanForm

logger = logging.getLogger(__name__)

def home(request):
    """Home page - redirect to dashboard if logged in, otherwise to login"""
    if request.user.is_authenticated:
        return redirect('dashboard')
    else:
        return redirect('login')

def get_user_currency_symbol(request):
    if request.user.is_authenticated:
        try:
            user_preference = UserPreference.objects.get(user=request.user)
            return user_preference.get_currency_symbol()
        except UserPreference.DoesNotExist:
            # Create default preferences if they don't exist
            user_preference = UserPreference.objects.create(user=request.user)
            return user_preference.get_currency_symbol()
    return '$'

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # Create user preferences
            UserPreference.objects.create(user=user)
            
            # Log the user in
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            
            messages.success(request, "Registration successful! Welcome to Expense Tracker.")
            return redirect('dashboard')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'tracker/register.html', {'form': form})

@login_required
def dashboard(request):
    try:
        # Get current month transactions
        current_month = datetime.now().month
        current_year = datetime.now().year
        
        transactions = Transaction.objects.filter(
            user=request.user,
            date__month=current_month,
            date__year=current_year
        )
        
        # Calculate totals
        income = transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
        expenses = transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0

        # Convert Decimal to float for template rendering
        income = float(income) if income else 0.0
        expenses = float(expenses) if expenses else 0.0
        balance = income - expenses
        
        # Get recent transactions
        recent_transactions = transactions.order_by('-date')[:5]
        
        # Get category breakdown for pie chart
        category_data = list(transactions.filter(type='expense').values('category').annotate(
            total=Sum('amount')).order_by('-total'))

        for item in category_data:
            # Convert Decimal to float for JSON serialization
            item['total'] = float(item['total']) if item['total'] else 0.0
            # Get the display name for the category
            for cat_choice in Transaction.CATEGORY_CHOICES:
                if cat_choice[0] == item['category']:
                    item['category_display'] = cat_choice[1]
                    break
            else:
                item['category_display'] = item['category']
        
        # Get monthly data for bar chart
        monthly_data = []
        
        # Get data for the last 6 months
        for i in range(5, -1, -1):
            # Calculate the month
            month_date = datetime.now().replace(day=1) - timedelta(days=i*30)
            month_name = month_date.strftime('%B')
            month_num = month_date.month
            year = month_date.year
            
            # Get month's transactions
            month_transactions = Transaction.objects.filter(
                user=request.user,
                date__month=month_num,
                date__year=year
            )
            
            # Calculate totals
            month_income = month_transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
            month_expenses = month_transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
            
            monthly_data.append({
                'month': month_name,
                'income': float(month_income),
                'expense': float(month_expenses)
            })
        
        # Get active loans
        active_loans = Loan.objects.filter(user=request.user, status='active')
        loans_given = active_loans.filter(loan_type='given').aggregate(Sum('amount'))['amount__sum'] or 0
        loans_taken = active_loans.filter(loan_type='taken').aggregate(Sum('amount'))['amount__sum'] or 0

        # Convert Decimal to float for template rendering
        loans_given = float(loans_given) if loans_given else 0.0
        loans_taken = float(loans_taken) if loans_taken else 0.0
        
        # Get user currency symbol
        currency_symbol = get_user_currency_symbol(request)
        
        return render(request, 'tracker/dashboard.html', {
            'income': income,
            'expenses': expenses,
            'balance': balance,
            'recent_transactions': recent_transactions,
            'category_data': json.dumps(category_data),
            'monthly_data': json.dumps(monthly_data),
            'loans_given': loans_given,
            'loans_taken': loans_taken,
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Dashboard error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def transaction_list(request):
    try:
        transactions = Transaction.objects.filter(user=request.user).order_by('-date')
        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/transaction_list.html', {
            'transactions': transactions,
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Transaction list error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def add_transaction(request):
    try:
        if request.method == 'POST':
            form = TransactionForm(request.POST)
            if form.is_valid():
                transaction = form.save(commit=False)
                transaction.user = request.user
                transaction.save()
                messages.success(request, "Transaction added successfully!")
                return redirect('transaction_list')
        else:
            form = TransactionForm(initial={'date': timezone.now().date()})
        
        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/transaction_form.html', {
            'form': form, 
            'title': 'Add Transaction',
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Add transaction error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def edit_transaction(request, pk):
    try:
        transaction = get_object_or_404(Transaction, id=pk, user=request.user)
        
        if request.method == 'POST':
            form = TransactionForm(request.POST, instance=transaction)
            if form.is_valid():
                form.save()
                messages.success(request, "Transaction updated successfully!")
                return redirect('transaction_list')
        else:
            form = TransactionForm(instance=transaction)
        
        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/transaction_form.html', {
            'form': form, 
            'title': 'Edit Transaction',
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Edit transaction error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def delete_transaction(request, pk):
    try:
        transaction = get_object_or_404(Transaction, id=pk, user=request.user)
        
        if request.method == 'POST':
            transaction.delete()
            messages.success(request, "Transaction deleted successfully!")
            return redirect('transaction_list')
        
        return render(request, 'tracker/confirm_delete.html', {'object': transaction, 'type': 'Transaction'})
    except Exception as e:
        logger.error(f"Delete transaction error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def budget_list(request):
    try:
        budgets = Budget.objects.filter(user=request.user).order_by('year', 'month')
        
        # Group budgets by month and year
        grouped_budgets = {}
        for budget in budgets:
            key = f"{budget.month} {budget.year}"
            if key not in grouped_budgets:
                grouped_budgets[key] = []
            grouped_budgets[key].append(budget)
        
        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/budget_list.html', {
            'grouped_budgets': grouped_budgets,
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Budget list error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def add_budget(request):
    try:
        if request.method == 'POST':
            form = BudgetForm(request.POST)
            if form.is_valid():
                budget = form.save(commit=False)
                budget.user = request.user
                
                # Check if budget already exists
                existing_budget = Budget.objects.filter(
                    user=request.user,
                    month=budget.month,
                    year=budget.year,
                    category=budget.category
                ).first()
                
                if existing_budget:
                    existing_budget.amount = budget.amount
                    existing_budget.save()
                    messages.success(request, "Budget updated successfully!")
                else:
                    budget.save()
                    messages.success(request, "Budget added successfully!")
                
                return redirect('budget_list')
        else:
            form = BudgetForm(initial={
                'month': datetime.now().strftime('%B'),
                'year': datetime.now().year
            })
        
        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/budget_form.html', {
            'form': form, 
            'title': 'Add Budget',
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Add budget error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def edit_budget(request, budget_id):
    try:
        budget = get_object_or_404(Budget, id=budget_id, user=request.user)
        
        if request.method == 'POST':
            form = BudgetForm(request.POST, instance=budget)
            if form.is_valid():
                form.save()
                messages.success(request, "Budget updated successfully!")
                return redirect('budget_list')
        else:
            form = BudgetForm(instance=budget)
        
        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/budget_form.html', {
            'form': form, 
            'title': 'Edit Budget',
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Edit budget error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def delete_budget(request, budget_id):
    try:
        budget = get_object_or_404(Budget, id=budget_id, user=request.user)
        
        if request.method == 'POST':
            budget.delete()
            messages.success(request, "Budget deleted successfully!")
            return redirect('budget_list')
        
        return render(request, 'tracker/confirm_delete.html', {'object': budget, 'type': 'Budget'})
    except Exception as e:
        logger.error(f"Delete budget error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def profile(request):
    try:
        # Get or create user preference
        user_preference, created = UserPreference.objects.get_or_create(
            user=request.user,
            defaults={'currency': 'USD', 'theme': 'light'}
        )
        
        if request.method == 'POST':
            form = UserPreferenceForm(request.POST, instance=user_preference)
            if form.is_valid():
                form.save()
                messages.success(request, "Preferences updated successfully!")
                return redirect('profile')
        else:
            form = UserPreferenceForm(instance=user_preference)
        
        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/profile.html', {
            'form': form,
            'currency_symbol': currency_symbol,
            'user': request.user
        })
    except Exception as e:
        logger.error(f"Profile error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def advanced_analysis_report(request):
    """
    Comprehensive Financial Analysis Report with Advanced Analytics
    """
    try:
        # Get comprehensive analysis period
        today = timezone.now().date()

        # Get filter parameters
        period = request.GET.get('period', '12')  # months
        category_filter = request.GET.get('category')
        analysis_type = request.GET.get('analysis_type', 'comprehensive')

        # Calculate date ranges
        if period == '3':
            months_back = 3
        elif period == '6':
            months_back = 6
        elif period == '24':
            months_back = 24
        else:
            months_back = 12

        # Current period
        current_start = today.replace(day=1) - timedelta(days=months_back * 30)
        current_end = today

        # Get all transactions for comprehensive analysis
        all_transactions = Transaction.objects.filter(
            user=request.user,
            date__gte=current_start,
            date__lte=current_end
        )

        # Apply category filter if specified
        if category_filter:
            all_transactions = all_transactions.filter(category=category_filter)

        # Separate income and expenses
        expenses = all_transactions.filter(type='expense')
        income = all_transactions.filter(type='income')

        # Calculate comprehensive financial metrics
        total_expenses = expenses.aggregate(Sum('amount'))['amount__sum'] or 0
        total_income = income.aggregate(Sum('amount'))['amount__sum'] or 0
        total_expenses = float(total_expenses)
        total_income = float(total_income)

        net_income = total_income - total_expenses
        savings_rate = (net_income / total_income * 100) if total_income > 0 else 0

        # Time-based calculations
        days_in_period = (current_end - current_start).days
        avg_daily_spending = total_expenses / days_in_period if days_in_period > 0 else 0
        avg_daily_income = total_income / days_in_period if days_in_period > 0 else 0

        # Monthly breakdown for charts
        monthly_data = []
        monthly_labels = []
        monthly_income_data = []
        monthly_expense_data = []
        monthly_net_data = []

        # Generate monthly data for the selected period
        current_date = current_start.replace(day=1)
        while current_date <= current_end:
            month_start = current_date
            if current_date.month == 12:
                month_end = current_date.replace(year=current_date.year + 1, month=1, day=1) - timedelta(days=1)
            else:
                month_end = current_date.replace(month=current_date.month + 1, day=1) - timedelta(days=1)

            if month_end > current_end:
                month_end = current_end

            month_expenses = expenses.filter(
                date__gte=month_start,
                date__lte=month_end
            ).aggregate(Sum('amount'))['amount__sum'] or 0

            month_income = income.filter(
                date__gte=month_start,
                date__lte=month_end
            ).aggregate(Sum('amount'))['amount__sum'] or 0

            month_expenses = float(month_expenses)
            month_income = float(month_income)
            month_net = month_income - month_expenses

            monthly_labels.append(current_date.strftime('%b %Y'))
            monthly_expense_data.append(month_expenses)
            monthly_income_data.append(month_income)
            monthly_net_data.append(month_net)

            monthly_data.append({
                'month': current_date.strftime('%B %Y'),
                'short_month': current_date.strftime('%b %Y'),
                'expenses': month_expenses,
                'income': month_income,
                'net': month_net,
                'savings_rate': (month_net / month_income * 100) if month_income > 0 else 0
            })

            # Move to next month
            if current_date.month == 12:
                current_date = current_date.replace(year=current_date.year + 1, month=1)
            else:
                current_date = current_date.replace(month=current_date.month + 1)

        # Enhanced Category Analysis
        category_analysis = []
        category_labels = []
        category_amounts = []
        category_colors = []

        # Predefined colors for categories
        color_palette = [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
            '#FF9F40', '#FF6384', '#C9CBCF', '#4BC0C0', '#FF6384'
        ]

        expense_categories = [cat for cat in Transaction.CATEGORY_CHOICES
                            if cat[0] not in ['salary', 'investment', 'business', 'other_income']]

        for i, (category_code, category_name) in enumerate(expense_categories):
            cat_transactions = expenses.filter(category=category_code)
            cat_total = cat_transactions.aggregate(Sum('amount'))['amount__sum'] or 0
            cat_count = cat_transactions.count()

            if cat_total > 0:
                cat_total = float(cat_total)
                avg_per_transaction = cat_total / cat_count if cat_count > 0 else 0
                percentage = (cat_total / total_expenses * 100) if total_expenses > 0 else 0

                color = color_palette[i % len(color_palette)]

                category_analysis.append({
                    'category': category_name,
                    'code': category_code,
                    'total': cat_total,
                    'count': cat_count,
                    'avg_per_transaction': avg_per_transaction,
                    'percentage': percentage,
                    'color': color
                })

                category_labels.append(category_name)
                category_amounts.append(cat_total)
                category_colors.append(color)

        # Sort by total amount
        category_analysis.sort(key=lambda x: x['total'], reverse=True)

        # Weekly analysis
        weekly_data = []
        weekly_labels = []
        weekly_amounts = []

        # Get last 12 weeks
        for i in range(12):
            week_start = today - timedelta(days=today.weekday() + 7 * i)
            week_end = week_start + timedelta(days=6)

            if week_start < current_start:
                break

            week_expenses = expenses.filter(
                date__gte=week_start,
                date__lte=week_end
            ).aggregate(Sum('amount'))['amount__sum'] or 0

            weekly_data.append({
                'week': f'Week {12-i}',
                'start_date': week_start,
                'end_date': week_end,
                'expenses': float(week_expenses)
            })

            weekly_labels.append(f'Week {12-i}')
            weekly_amounts.append(float(week_expenses))

        weekly_data.reverse()
        weekly_labels.reverse()
        weekly_amounts.reverse()

        # Daily analysis for last 30 days
        daily_data = []
        daily_labels = []
        daily_amounts = []

        for i in range(30):
            day = today - timedelta(days=i)
            if day < current_start:
                break

            day_expenses = expenses.filter(date=day).aggregate(Sum('amount'))['amount__sum'] or 0

            daily_data.append({
                'date': day,
                'expenses': float(day_expenses)
            })

            daily_labels.append(day.strftime('%m/%d'))
            daily_amounts.append(float(day_expenses))

        daily_data.reverse()
        daily_labels.reverse()
        daily_amounts.reverse()

        # Weekday analysis
        weekday_totals = [0] * 7  # Monday = 0, Sunday = 6
        weekday_labels = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

        for transaction in expenses:
            weekday = transaction.date.weekday()
            weekday_totals[weekday] += float(transaction.amount)

        # Advanced analytics
        largest_expense = expenses.order_by('-amount').first()
        largest_income = income.order_by('-amount').first()

        # Calculate trends
        spending_trend = 'stable'
        income_trend = 'stable'

        if len(monthly_expense_data) >= 2:
            recent_spending = sum(monthly_expense_data[-2:]) / 2
            older_spending = sum(monthly_expense_data[:2]) / 2 if len(monthly_expense_data) >= 2 else monthly_expense_data[0]

            if recent_spending > older_spending * 1.1:
                spending_trend = 'increasing'
            elif recent_spending < older_spending * 0.9:
                spending_trend = 'decreasing'

        if len(monthly_income_data) >= 2:
            recent_income = sum(monthly_income_data[-2:]) / 2
            older_income = sum(monthly_income_data[:2]) / 2 if len(monthly_income_data) >= 2 else monthly_income_data[0]

            if recent_income > older_income * 1.1:
                income_trend = 'increasing'
            elif recent_income < older_income * 0.9:
                income_trend = 'decreasing'

        # Calculate volatility
        expense_volatility = 0
        income_stability = 0

        if len(monthly_expense_data) > 1:
            expense_mean = sum(monthly_expense_data) / len(monthly_expense_data)
            expense_variance = sum((x - expense_mean) ** 2 for x in monthly_expense_data) / len(monthly_expense_data)
            expense_volatility = (expense_variance ** 0.5 / expense_mean * 100) if expense_mean > 0 else 0

        if len(monthly_income_data) > 1:
            income_mean = sum(monthly_income_data) / len(monthly_income_data)
            income_variance = sum((x - income_mean) ** 2 for x in monthly_income_data) / len(monthly_income_data)
            income_stability = max(0, 100 - (income_variance ** 0.5 / income_mean * 100)) if income_mean > 0 else 0

        # Transaction frequency
        transaction_frequency = all_transactions.count() / days_in_period if days_in_period > 0 else 0

        # Get user preferences for currency
        try:
            user_preference = UserPreference.objects.get(user=request.user)
            currency_symbol = user_preference.get_currency_symbol()
        except UserPreference.DoesNotExist:
            currency_symbol = '$'

        # Prepare context for template
        context = {
            # Basic metrics
            'total_expenses': total_expenses,
            'total_income': total_income,
            'net_income': net_income,
            'savings_rate': (net_income / total_income * 100) if total_income > 0 else 0,
            'avg_daily_spending': total_expenses / days_in_period if days_in_period > 0 else 0,
            'avg_daily_income': total_income / days_in_period if days_in_period > 0 else 0,
            'weekly_average': (total_expenses / days_in_period * 7) if days_in_period > 0 else 0,

            # Chart data
            'monthly_labels': monthly_labels,
            'monthly_income_data': monthly_income_data,
            'monthly_expense_data': monthly_expense_data,
            'monthly_net_data': monthly_net_data,

            'category_labels': category_labels,
            'category_amounts': category_amounts,
            'category_colors': category_colors,

            'weekly_labels': weekly_labels,
            'weekly_amounts': weekly_amounts,

            'daily_labels': daily_labels,
            'daily_amounts': daily_amounts,

            'weekday_labels': weekday_labels,
            'weekday_totals': weekday_totals,

            # Analysis data
            'monthly_data': monthly_data,
            'category_analysis': category_analysis,
            'weekly_data': weekly_data,
            'daily_data': daily_data,

            # Advanced analytics
            'spending_trend': spending_trend,
            'income_trend': income_trend,
            'expense_volatility': expense_volatility,
            'income_stability': income_stability,
            'transaction_frequency': transaction_frequency,
            'largest_expense': largest_expense,
            'largest_income': largest_income,

            # Create advanced analytics object for template compatibility
            'advanced_analytics': {
                'savings_rate': (net_income / total_income * 100) if total_income > 0 else 0,
                'expense_income_ratio': (total_expenses / total_income * 100) if total_income > 0 else 0,
                'daily_burn_rate': total_expenses / days_in_period if days_in_period > 0 else 0,
                'projected_monthly_expenses': (total_expenses / days_in_period * 30) if days_in_period > 0 else 0,
                'projected_annual_expenses': (total_expenses / days_in_period * 365) if days_in_period > 0 else 0,
                'most_active_day': None,
                'spending_velocity': transaction_frequency,
                'income_stability': income_stability,
                'financial_momentum': 0,
                'expense_volatility': expense_volatility,
                'income_growth_rate': 0,
                'expense_growth_rate': 0,
                'cash_flow_trend': spending_trend,
                'spending_efficiency': 75,  # Default value
                'financial_discipline_score': 80,  # Default value
                'emergency_fund_months': 3,  # Default value
                'debt_to_income_ratio': 0,
                'investment_rate': 0
            },

            # Filter parameters
            'period': period,
            'category_filter': category_filter,
            'analysis_type': analysis_type,
            'currency_symbol': currency_symbol,
            'categories': Transaction.CATEGORY_CHOICES,

            # Meta data
            'days_in_period': days_in_period,
            'current_start': current_start,
            'current_end': current_end,
        }

        return render(request, 'tracker/advanced_analysis_report.html', context)

    except Exception as e:
        logger.error(f"Advanced analysis error: {str(e)}")
        messages.error(request, f"An error occurred while generating the analysis: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})


@login_required
def spending_analysis(request):
    """
    Legacy spending analysis view - redirects to advanced analysis
    """
    return redirect('advanced_analysis_report')

@login_required
def reports(request):
    try:
        # Default date range (last 12 months for comprehensive analysis)
        end_date = timezone.now().date()
        start_date = end_date.replace(day=1) - timedelta(days=365)

        # Get filter parameters from both GET and POST
        if request.method == 'POST':
            start_date_str = request.POST.get('start_date')
            end_date_str = request.POST.get('end_date')
            transaction_type = request.POST.get('type')
            category = request.POST.get('category')
            report_type = request.POST.get('report_type', 'summary')

            # Convert string dates to date objects
            if start_date_str:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            if end_date_str:
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
        else:
            start_date_str = request.GET.get('start_date')
            end_date_str = request.GET.get('end_date')
            transaction_type = request.GET.get('type')
            category = request.GET.get('category')
            report_type = request.GET.get('report_type', 'summary')

            # Convert string dates to date objects
            if start_date_str:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            if end_date_str:
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()

        # Base query
        all_transactions = Transaction.objects.filter(user=request.user)
        transactions = all_transactions.filter(date__gte=start_date, date__lte=end_date)

        # Apply other filters
        if transaction_type:
            transactions = transactions.filter(type=transaction_type)
        if category:
            transactions = transactions.filter(category=category)

        # Calculate comprehensive statistics
        total_income = transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
        total_expenses = transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
        total_income = float(total_income) if total_income else 0.0
        total_expenses = float(total_expenses) if total_expenses else 0.0
        net = total_income - total_expenses

        # Calculate averages
        days_in_period = (end_date - start_date).days + 1
        avg_daily_income = total_income / days_in_period if days_in_period > 0 else 0
        avg_daily_expenses = total_expenses / days_in_period if days_in_period > 0 else 0

        # Calculate transaction counts
        income_count = transactions.filter(type='income').count()
        expense_count = transactions.filter(type='expense').count()
        avg_income_per_transaction = total_income / income_count if income_count > 0 else 0
        avg_expense_per_transaction = total_expenses / expense_count if expense_count > 0 else 0

        # Generate monthly summary with trends
        monthly_data = []
        current_date = start_date.replace(day=1)
        previous_month_expenses = 0

        while current_date <= end_date:
            month_transactions = transactions.filter(
                date__year=current_date.year,
                date__month=current_date.month
            )

            month_income = month_transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
            month_expenses = month_transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
            month_income = float(month_income) if month_income else 0.0
            month_expenses = float(month_expenses) if month_expenses else 0.0

            # Calculate trend
            trend = 0
            if previous_month_expenses > 0:
                trend = ((month_expenses - previous_month_expenses) / previous_month_expenses) * 100

            monthly_data.append({
                'month': current_date.strftime('%B %Y'),
                'short_month': current_date.strftime('%b %Y'),
                'income': month_income,
                'expenses': month_expenses,
                'net': month_income - month_expenses,
                'trend': trend,
                'transaction_count': month_transactions.count()
            })

            previous_month_expenses = month_expenses

            # Move to next month
            if current_date.month == 12:
                current_date = current_date.replace(year=current_date.year + 1, month=1)
            else:
                current_date = current_date.replace(month=current_date.month + 1)

        # Enhanced category analysis with colors and insights
        category_data = []
        income_category_data = []

        # Define category colors for better visualization
        category_colors = {
            'food': '#FF6384',
            'transportation': '#36A2EB',
            'shopping': '#FFCE56',
            'entertainment': '#4BC0C0',
            'healthcare': '#9966FF',
            'utilities': '#FF9F40',
            'education': '#FF6384',
            'travel': '#C9CBCF',
            'housing': '#4BC0C0',
            'insurance': '#FF6384',
            'personal_care': '#36A2EB',
            'gifts': '#FFCE56',
            'other_expense': '#6c757d'
        }

        for category_code, category_name in Transaction.CATEGORY_CHOICES:
            # Expense categories
            if category_code not in ['salary', 'investment', 'business', 'other_income']:
                category_total = transactions.filter(category=category_code, type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
                category_count = transactions.filter(category=category_code, type='expense').count()

                if category_total > 0:
                    category_total_float = float(category_total)
                    percentage = (category_total_float / total_expenses * 100) if total_expenses > 0 else 0
                    avg_per_transaction = category_total_float / category_count if category_count > 0 else 0

                    category_data.append({
                        'category': category_name,
                        'code': category_code,
                        'total': category_total_float,
                        'count': category_count,
                        'avg_per_transaction': avg_per_transaction,
                        'percentage': percentage,
                        'color': category_colors.get(category_code, '#6c757d'),
                        'is_high_spending': percentage > 20,  # Flag for high spending categories
                        'monthly_average': category_total_float / max(1, (end_date - start_date).days / 30),
                        'trend': 'stable'  # Could be enhanced with historical comparison
                    })

            # Income categories
            else:
                category_total = transactions.filter(category=category_code, type='income').aggregate(Sum('amount'))['amount__sum'] or 0
                category_count = transactions.filter(category=category_code, type='income').count()

                if category_total > 0:
                    category_total_float = float(category_total)
                    percentage = (category_total_float / total_income * 100) if total_income > 0 else 0
                    avg_per_transaction = category_total_float / category_count if category_count > 0 else 0

                    income_category_data.append({
                        'category': category_name,
                        'code': category_code,
                        'total': category_total_float,
                        'count': category_count,
                        'avg_per_transaction': avg_per_transaction,
                        'percentage': percentage,
                        'color': category_colors.get(category_code, '#28a745'),
                        'monthly_average': category_total_float / max(1, (end_date - start_date).days / 30)
                    })

        # Sort categories by total amount
        category_data.sort(key=lambda x: x['total'], reverse=True)
        income_category_data.sort(key=lambda x: x['total'], reverse=True)

        # Enhanced insights and analytics
        category_insights = {
            'total_categories': len(category_data),
            'top_3_percentage': 0,
            'most_frequent_category': None,
            'highest_avg_category': None,
            'spending_diversity_index': 0,
            'budget_efficiency': 0,
            'financial_health_score': 0
        }

        if category_data:
            # Calculate top 3 categories percentage
            top_3_total = sum([cat['total'] for cat in category_data[:3]])
            category_insights['top_3_percentage'] = (top_3_total / total_expenses * 100) if total_expenses > 0 else 0

            # Find most frequent category
            category_insights['most_frequent_category'] = max(category_data, key=lambda x: x['count'])

            # Find highest average category
            category_insights['highest_avg_category'] = max(category_data, key=lambda x: x['avg_per_transaction'])

            # Calculate spending diversity index (lower = more concentrated spending)
            if total_expenses > 0:
                diversity_score = 0
                for cat in category_data:
                    if cat['percentage'] > 0:
                        diversity_score += (cat['percentage'] / 100) * math.log(cat['percentage'] / 100)
                category_insights['spending_diversity_index'] = -diversity_score * 100

            # Calculate financial health score (0-100)
            savings_rate = (net / total_income * 100) if total_income > 0 else 0
            expense_ratio = (total_expenses / total_income * 100) if total_income > 0 else 100

            health_score = 0
            if savings_rate > 20:
                health_score += 40
            elif savings_rate > 10:
                health_score += 25
            elif savings_rate > 0:
                health_score += 10

            if expense_ratio < 70:
                health_score += 30
            elif expense_ratio < 85:
                health_score += 20
            elif expense_ratio < 95:
                health_score += 10

            # Bonus for spending diversity
            if category_insights['spending_diversity_index'] > 50:
                health_score += 20
            elif category_insights['spending_diversity_index'] > 30:
                health_score += 10

            # Penalty for high concentration in single category
            if category_data and category_data[0]['percentage'] > 50:
                health_score -= 10

            category_insights['financial_health_score'] = min(100, max(0, health_score))

        # Weekly analysis
        weekly_data = []
        current_week_start = start_date - timedelta(days=start_date.weekday())

        while current_week_start <= end_date:
            week_end = current_week_start + timedelta(days=6)
            week_transactions = transactions.filter(date__gte=current_week_start, date__lte=week_end)

            week_income = week_transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
            week_expenses = week_transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0

            weekly_data.append({
                'week_start': current_week_start,
                'week_end': week_end,
                'income': float(week_income) if week_income else 0.0,
                'expenses': float(week_expenses) if week_expenses else 0.0,
                'net': float(week_income or 0) - float(week_expenses or 0),
                'transaction_count': week_transactions.count()
            })

            current_week_start += timedelta(days=7)

        # Top transactions analysis
        top_expenses = transactions.filter(type='expense').order_by('-amount')[:10]
        top_income = transactions.filter(type='income').order_by('-amount')[:10]

        # Comparison with previous period
        previous_start = start_date - (end_date - start_date + timedelta(days=1))
        previous_end = start_date - timedelta(days=1)
        previous_transactions = all_transactions.filter(date__gte=previous_start, date__lte=previous_end)

        prev_income = previous_transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
        prev_expenses = previous_transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
        prev_income = float(prev_income) if prev_income else 0.0
        prev_expenses = float(prev_expenses) if prev_expenses else 0.0

        income_change = ((total_income - prev_income) / prev_income * 100) if prev_income > 0 else 0
        expense_change = ((total_expenses - prev_expenses) / prev_expenses * 100) if prev_expenses > 0 else 0

        # Enhanced Advanced Analytics
        advanced_analytics = {
            'savings_rate': (net / total_income * 100) if total_income > 0 else 0,
            'expense_income_ratio': (total_expenses / total_income * 100) if total_income > 0 else 0,
            'daily_burn_rate': total_expenses / days_in_period if days_in_period > 0 else 0,
            'projected_monthly_expenses': (total_expenses / days_in_period * 30) if days_in_period > 0 else 0,
            'projected_annual_expenses': (total_expenses / days_in_period * 365) if days_in_period > 0 else 0,
            'largest_expense': transactions.filter(type='expense').order_by('-amount').first(),
            'largest_income': transactions.filter(type='income').order_by('-amount').first(),
            'most_active_day': None,
            'spending_velocity': 0,
            'income_stability': 0,
            'financial_momentum': 0,
            'expense_volatility': 0,
            'income_growth_rate': 0,
            'expense_growth_rate': 0,
            'cash_flow_trend': 'stable',
            'spending_efficiency': 0,
            'financial_discipline_score': 0,
            'emergency_fund_months': 0,
            'debt_to_income_ratio': 0,
            'investment_rate': 0
        }

        # Calculate most active day
        if transactions.exists():
            from django.db.models import Count
            day_activity = transactions.values('date').annotate(
                transaction_count=Count('id'),
                daily_total=Sum('amount')
            ).order_by('-transaction_count').first()

            if day_activity:
                advanced_analytics['most_active_day'] = {
                    'date': day_activity['date'],
                    'count': day_activity['transaction_count'],
                    'total': float(day_activity['daily_total'])
                }

        # Calculate spending velocity (transactions per day)
        advanced_analytics['spending_velocity'] = (income_count + expense_count) / days_in_period if days_in_period > 0 else 0

        # Enhanced Financial Analytics
        import statistics

        # Calculate income stability and growth
        if monthly_data and len(monthly_data) > 1:
            monthly_incomes = [month['income'] for month in monthly_data if month['income'] > 0]
            monthly_expenses = [month['expenses'] for month in monthly_data if month['expenses'] > 0]

            # Income stability (coefficient of variation)
            if len(monthly_incomes) > 1:
                mean_income = statistics.mean(monthly_incomes)
                std_income = statistics.stdev(monthly_incomes)
                advanced_analytics['income_stability'] = (1 - (std_income / mean_income)) * 100 if mean_income > 0 else 0

            # Income growth rate (comparing first half vs second half)
            if len(monthly_incomes) >= 4:
                mid_point = len(monthly_incomes) // 2
                first_half_avg = statistics.mean(monthly_incomes[:mid_point])
                second_half_avg = statistics.mean(monthly_incomes[mid_point:])
                advanced_analytics['income_growth_rate'] = ((second_half_avg - first_half_avg) / first_half_avg * 100) if first_half_avg > 0 else 0

            # Expense volatility and growth
            if len(monthly_expenses) > 1:
                mean_expense = statistics.mean(monthly_expenses)
                std_expense = statistics.stdev(monthly_expenses)
                advanced_analytics['expense_volatility'] = (std_expense / mean_expense * 100) if mean_expense > 0 else 0

                # Expense growth rate
                if len(monthly_expenses) >= 4:
                    mid_point = len(monthly_expenses) // 2
                    first_half_avg = statistics.mean(monthly_expenses[:mid_point])
                    second_half_avg = statistics.mean(monthly_expenses[mid_point:])
                    advanced_analytics['expense_growth_rate'] = ((second_half_avg - first_half_avg) / first_half_avg * 100) if first_half_avg > 0 else 0

        # Financial momentum (trend analysis)
        if len(monthly_data) >= 3:
            recent_months = monthly_data[-3:]
            net_balances = [month['income'] - month['expenses'] for month in recent_months]
            if len(net_balances) >= 2:
                momentum = sum(net_balances[-2:]) - sum(net_balances[:-2]) if len(net_balances) > 2 else net_balances[-1] - net_balances[0]
                advanced_analytics['financial_momentum'] = momentum

                # Cash flow trend
                if momentum > total_income * 0.05:  # 5% of income
                    advanced_analytics['cash_flow_trend'] = 'improving'
                elif momentum < -total_income * 0.05:
                    advanced_analytics['cash_flow_trend'] = 'declining'
                else:
                    advanced_analytics['cash_flow_trend'] = 'stable'

        # Spending efficiency (value per transaction)
        if expense_count > 0:
            avg_expense_size = total_expenses / expense_count
            # Compare to median expense to detect efficiency
            expense_amounts = [float(t.amount) for t in transactions.filter(type='expense')]
            if expense_amounts:
                median_expense = statistics.median(expense_amounts)
                advanced_analytics['spending_efficiency'] = (median_expense / avg_expense_size * 100) if avg_expense_size > 0 else 0

        # Financial discipline score (consistency in spending)
        discipline_score = 100
        if advanced_analytics['expense_volatility'] > 30:
            discipline_score -= 20
        if advanced_analytics['savings_rate'] < 10:
            discipline_score -= 25
        if len(category_data) > 0 and category_data[0]['percentage'] > 40:  # Over-concentration
            discipline_score -= 15
        if advanced_analytics['expense_growth_rate'] > 10:  # Expense growth too high
            discipline_score -= 20
        advanced_analytics['financial_discipline_score'] = max(0, discipline_score)

        # Emergency fund calculation (months of expenses covered)
        if total_expenses > 0:
            monthly_expenses = total_expenses / (days_in_period / 30) if days_in_period > 0 else total_expenses
            # Assume current balance is net income (simplified)
            advanced_analytics['emergency_fund_months'] = abs(net) / monthly_expenses if monthly_expenses > 0 else 0

        # Investment rate (percentage going to investments)
        investment_transactions = transactions.filter(category='investment', type='expense')
        investment_total = investment_transactions.aggregate(Sum('amount'))['amount__sum'] or 0
        investment_total = float(investment_total) if investment_total else 0.0
        advanced_analytics['investment_rate'] = (investment_total / total_income * 100) if total_income > 0 else 0

        # Debt to income ratio (loans taken vs income)
        debt_transactions = transactions.filter(category__in=['loan', 'credit'], type='expense')
        debt_total = debt_transactions.aggregate(Sum('amount'))['amount__sum'] or 0
        debt_total = float(debt_total) if debt_total else 0.0
        advanced_analytics['debt_to_income_ratio'] = (debt_total / total_income * 100) if total_income > 0 else 0

        # Budget Analysis (if budgets exist)
        budget_analysis = {
            'total_budgets': 0,
            'budgets_exceeded': 0,
            'budget_utilization': 0,
            'budget_variance': 0,
            'budget_efficiency_score': 0
        }

        try:
            from .models import Budget
            current_month = timezone.now().date().replace(day=1)
            current_budgets = Budget.objects.filter(user=request.user, month=current_month)

            if current_budgets.exists():
                budget_analysis['total_budgets'] = current_budgets.count()
                total_budget_amount = sum(float(b.amount) for b in current_budgets)

                budgets_exceeded = 0
                total_variance = 0

                for budget in current_budgets:
                    category_spending = transactions.filter(
                        category=budget.category,
                        type='expense',
                        date__month=current_month.month,
                        date__year=current_month.year
                    ).aggregate(Sum('amount'))['amount__sum'] or 0

                    category_spending = float(category_spending)
                    budget_amount = float(budget.amount)

                    if category_spending > budget_amount:
                        budgets_exceeded += 1

                    variance = abs(category_spending - budget_amount)
                    total_variance += variance

                budget_analysis['budgets_exceeded'] = budgets_exceeded
                budget_analysis['budget_utilization'] = (total_expenses / total_budget_amount * 100) if total_budget_amount > 0 else 0
                budget_analysis['budget_variance'] = total_variance / budget_analysis['total_budgets'] if budget_analysis['total_budgets'] > 0 else 0

                # Calculate efficiency score
                efficiency = 100 - (budgets_exceeded / budget_analysis['total_budgets'] * 50) if budget_analysis['total_budgets'] > 0 else 100
                efficiency -= min(50, abs(budget_analysis['budget_utilization'] - 85) * 2)  # Optimal utilization around 85%
                budget_analysis['budget_efficiency_score'] = max(0, efficiency)
        except:
            pass  # Budget model might not exist or other issues

        currency_symbol = get_user_currency_symbol(request)

        context = {
            'transactions': transactions.order_by('-date'),
            'total_income': total_income,
            'total_expenses': total_expenses,
            'net': net,
            'avg_daily_income': avg_daily_income,
            'avg_daily_expenses': avg_daily_expenses,
            'avg_income_per_transaction': avg_income_per_transaction,
            'avg_expense_per_transaction': avg_expense_per_transaction,
            'income_count': income_count,
            'expense_count': expense_count,
            'monthly_data': monthly_data,
            'weekly_data': weekly_data[-8:],  # Last 8 weeks
            'category_data': category_data,
            'income_category_data': income_category_data,
            'category_insights': category_insights,
            'advanced_analytics': advanced_analytics,
            'budget_analysis': budget_analysis,
            'top_expenses': top_expenses,
            'top_income': top_income,
            'income_change': income_change,
            'expense_change': expense_change,
            'prev_income': prev_income,
            'prev_expenses': prev_expenses,
            'start_date': start_date,
            'end_date': end_date,
            'selected_type': transaction_type,
            'selected_category': category,
            'report_type': report_type,
            'currency_symbol': currency_symbol,
            'categories': Transaction.CATEGORY_CHOICES,
            'days_in_period': days_in_period
        }

        return render(request, 'tracker/reports.html', context)
    except Exception as e:
        logger.error(f"Reports error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def export_transactions(request):
    try:
        # Get all transactions for the user
        transactions = Transaction.objects.filter(user=request.user).order_by('-date')
        
        # Create CSV response
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="transactions.csv"'
        
        # Write to CSV
        writer = csv.writer(response)
        writer.writerow(['Date', 'Type', 'Category', 'Amount', 'Description'])
        
        for transaction in transactions:
            writer.writerow([
                transaction.date,
                transaction.get_type_display(),
                transaction.get_category_display(),
                transaction.amount,
                transaction.description
            ])
        
        return response
    except Exception as e:
        logger.error(f"Export transactions error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def export_financial_report(request):
    """Export comprehensive financial report with analytics"""
    try:
        # Get date range from request
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')

        if start_date and end_date:
            try:
                # Try YYYY-MM-DD format first
                start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
                end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
            except ValueError:
                try:
                    # Try "Month DD, YYYY" format
                    start_date = datetime.strptime(start_date, '%B %d, %Y').date()
                    end_date = datetime.strptime(end_date, '%B %d, %Y').date()
                except ValueError:
                    # Default to current month if parsing fails
                    today = timezone.now().date()
                    start_date = today.replace(day=1)
                    end_date = today
        else:
            # Default to current month
            today = timezone.now().date()
            start_date = today.replace(day=1)
            end_date = today

        # Get transactions for the period
        transactions = Transaction.objects.filter(
            user=request.user,
            date__gte=start_date,
            date__lte=end_date
        )

        # Calculate analytics
        total_income = transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
        total_expenses = transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
        total_income = float(total_income) if total_income else 0.0
        total_expenses = float(total_expenses) if total_expenses else 0.0
        net = total_income - total_expenses

        # Create HTTP response with CSV content type
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="financial_report_{start_date}_to_{end_date}.csv"'

        # Create CSV writer
        writer = csv.writer(response)

        # Write report header
        writer.writerow(['FINANCIAL REPORT'])
        writer.writerow([f'Period: {start_date} to {end_date}'])
        writer.writerow([f'Generated: {timezone.now().strftime("%Y-%m-%d %H:%M:%S")}'])
        writer.writerow([])

        # Write summary
        writer.writerow(['SUMMARY'])
        writer.writerow(['Total Income', f'${total_income:.2f}'])
        writer.writerow(['Total Expenses', f'${total_expenses:.2f}'])
        writer.writerow(['Net Amount', f'${net:.2f}'])
        writer.writerow(['Savings Rate', f'{(net/total_income*100):.1f}%' if total_income > 0 else '0%'])
        writer.writerow([])

        # Write category breakdown
        writer.writerow(['EXPENSE CATEGORIES'])
        writer.writerow(['Category', 'Amount', 'Percentage', 'Transaction Count'])

        for category_code, category_name in Transaction.CATEGORY_CHOICES:
            if category_code not in ['salary', 'investment', 'business', 'other_income']:
                category_total = transactions.filter(category=category_code, type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
                category_count = transactions.filter(category=category_code, type='expense').count()
                category_total = float(category_total) if category_total else 0.0
                percentage = (category_total / total_expenses * 100) if total_expenses > 0 else 0

                if category_total > 0:
                    writer.writerow([
                        category_name,
                        f'${category_total:.2f}',
                        f'{percentage:.1f}%',
                        category_count
                    ])

        writer.writerow([])

        # Write transaction details
        writer.writerow(['TRANSACTION DETAILS'])
        writer.writerow(['Date', 'Type', 'Category', 'Amount', 'Description'])

        for transaction in transactions.order_by('-date'):
            writer.writerow([
                transaction.date.strftime('%Y-%m-%d'),
                transaction.type.title(),
                transaction.get_category_display(),
                f'${transaction.amount:.2f}',
                transaction.description
            ])

        return response
    except Exception as e:
        logger.error(f"Export financial report error: {str(e)}")
        messages.error(request, "Error exporting financial report.")
        return redirect('reports')

@login_required
def export_pdf_report(request):
    """Export comprehensive PDF report with embedded graphs"""
    try:
        import io
        import matplotlib
        matplotlib.use('Agg')  # Use non-interactive backend
        import matplotlib.pyplot as plt
        import seaborn as sns
        from reportlab.lib.pagesizes import letter, A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

        # Get date range from request
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')

        if start_date and end_date:
            try:
                # Try YYYY-MM-DD format first
                start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
                end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
            except ValueError:
                try:
                    # Try "Month DD, YYYY" format
                    start_date = datetime.strptime(start_date, '%B %d, %Y').date()
                    end_date = datetime.strptime(end_date, '%B %d, %Y').date()
                except ValueError:
                    # Default to current month if parsing fails
                    today = timezone.now().date()
                    start_date = today.replace(day=1)
                    end_date = today
        else:
            # Default to current month
            today = timezone.now().date()
            start_date = today.replace(day=1)
            end_date = today

        # Get transactions for the period
        transactions = Transaction.objects.filter(
            user=request.user,
            date__gte=start_date,
            date__lte=end_date
        )

        # Calculate analytics (reuse logic from reports view)
        total_income = transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
        total_expenses = transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
        total_income = float(total_income) if total_income else 0.0
        total_expenses = float(total_expenses) if total_expenses else 0.0
        net = total_income - total_expenses

        # Get category data
        category_data = []
        for category_code, category_name in Transaction.CATEGORY_CHOICES:
            if category_code not in ['salary', 'investment', 'business', 'other_income']:
                category_total = transactions.filter(category=category_code, type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
                category_count = transactions.filter(category=category_code, type='expense').count()
                category_total = float(category_total) if category_total else 0.0

                if category_total > 0:
                    percentage = (category_total / total_expenses * 100) if total_expenses > 0 else 0
                    category_data.append({
                        'category': category_name,
                        'total': category_total,
                        'percentage': percentage,
                        'count': category_count
                    })

        category_data.sort(key=lambda x: x['total'], reverse=True)

        # Create PDF buffer
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)

        # Container for the 'Flowable' objects
        elements = []

        # Define styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#2c3e50')
        )

        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=16,
            spaceAfter=12,
            textColor=colors.HexColor('#34495e')
        )

        # Title
        title = Paragraph(f"Financial Report<br/>{start_date.strftime('%B %d, %Y')} - {end_date.strftime('%B %d, %Y')}", title_style)
        elements.append(title)
        elements.append(Spacer(1, 20))

        # Summary section
        summary_heading = Paragraph("Executive Summary", heading_style)
        elements.append(summary_heading)

        summary_data = [
            ['Metric', 'Amount', 'Details'],
            ['Total Income', f'${total_income:,.2f}', f'{transactions.filter(type="income").count()} transactions'],
            ['Total Expenses', f'${total_expenses:,.2f}', f'{transactions.filter(type="expense").count()} transactions'],
            ['Net Balance', f'${net:,.2f}', 'Positive' if net >= 0 else 'Negative'],
            ['Savings Rate', f'{(net/total_income*100):.1f}%' if total_income > 0 else '0%', 'Income - Expenses / Income'],
        ]

        summary_table = Table(summary_data, colWidths=[2*inch, 1.5*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3498db')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))

        elements.append(summary_table)
        elements.append(Spacer(1, 20))

        # Generate charts
        chart_images = []

        # 1. Category Pie Chart
        if category_data:
            plt.figure(figsize=(8, 6))
            categories = [cat['category'] for cat in category_data[:8]]  # Top 8 categories
            amounts = [cat['total'] for cat in category_data[:8]]
            colors_list = plt.cm.Set3(range(len(categories)))

            plt.pie(amounts, labels=categories, autopct='%1.1f%%', colors=colors_list, startangle=90)
            plt.title('Expense Categories Distribution', fontsize=16, fontweight='bold')
            plt.axis('equal')

            # Save chart to buffer
            chart_buffer = io.BytesIO()
            plt.savefig(chart_buffer, format='png', dpi=300, bbox_inches='tight')
            chart_buffer.seek(0)
            plt.close()

            # Add chart to PDF
            chart_heading = Paragraph("Expense Categories Breakdown", heading_style)
            elements.append(chart_heading)
            chart_image = Image(chart_buffer, width=6*inch, height=4.5*inch)
            elements.append(chart_image)
            elements.append(Spacer(1, 20))

        # 2. Income vs Expenses Bar Chart
        if total_income > 0 or total_expenses > 0:
            plt.figure(figsize=(8, 6))
            categories = ['Income', 'Expenses', 'Net Balance']
            amounts = [total_income, total_expenses, net]
            colors_list = ['#2ecc71', '#e74c3c', '#3498db' if net >= 0 else '#f39c12']

            bars = plt.bar(categories, amounts, color=colors_list)
            plt.title('Financial Overview', fontsize=16, fontweight='bold')
            plt.ylabel('Amount ($)')

            # Add value labels on bars
            for bar, amount in zip(bars, amounts):
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height + max(amounts)*0.01,
                        f'${amount:,.0f}', ha='center', va='bottom', fontweight='bold')

            plt.grid(axis='y', alpha=0.3)
            plt.tight_layout()

            # Save chart to buffer
            chart_buffer = io.BytesIO()
            plt.savefig(chart_buffer, format='png', dpi=300, bbox_inches='tight')
            chart_buffer.seek(0)
            plt.close()

            # Add chart to PDF
            chart_heading = Paragraph("Income vs Expenses Overview", heading_style)
            elements.append(chart_heading)
            chart_image = Image(chart_buffer, width=6*inch, height=4.5*inch)
            elements.append(chart_image)
            elements.append(Spacer(1, 20))

        # Category breakdown table
        if category_data:
            category_heading = Paragraph("Detailed Category Analysis", heading_style)
            elements.append(category_heading)

            category_table_data = [['Category', 'Amount', 'Percentage', 'Transactions']]
            for cat in category_data[:10]:  # Top 10 categories
                category_table_data.append([
                    cat['category'],
                    f"${cat['total']:,.2f}",
                    f"{cat['percentage']:.1f}%",
                    str(cat['count'])
                ])

            category_table = Table(category_table_data, colWidths=[2*inch, 1.5*inch, 1*inch, 1*inch])
            category_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e74c3c')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))

            elements.append(category_table)
            elements.append(Spacer(1, 20))

        # Recent transactions table
        recent_transactions = transactions.order_by('-date')[:10]
        if recent_transactions:
            transactions_heading = Paragraph("Recent Transactions", heading_style)
            elements.append(transactions_heading)

            transactions_data = [['Date', 'Type', 'Category', 'Amount', 'Description']]
            for transaction in recent_transactions:
                transactions_data.append([
                    transaction.date.strftime('%m/%d/%Y'),
                    transaction.type.title(),
                    transaction.get_category_display(),
                    f"${transaction.amount:.2f}",
                    transaction.description[:30] + '...' if len(transaction.description) > 30 else transaction.description
                ])

            transactions_table = Table(transactions_data, colWidths=[1*inch, 0.8*inch, 1.2*inch, 1*inch, 2*inch])
            transactions_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#9b59b6')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.lightblue),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))

            elements.append(transactions_table)

        # Build PDF
        doc.build(elements)

        # Get PDF data
        pdf_data = buffer.getvalue()
        buffer.close()

        # Create response
        response = HttpResponse(pdf_data, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="financial_report_{start_date}_to_{end_date}.pdf"'

        return response
    except Exception as e:
        logger.error(f"Export PDF report error: {str(e)}")
        messages.error(request, "Error exporting PDF report.")
        return redirect('reports')

@login_required
def test_view(request):
    """A comprehensive test view to check all functionality"""
    try:
        # Test database queries
        transactions_count = Transaction.objects.filter(user=request.user).count()
        budgets_count = Budget.objects.filter(user=request.user).count()
        loans_count = Loan.objects.filter(user=request.user).count()

        # Test aggregations
        total_income = Transaction.objects.filter(user=request.user, type='income').aggregate(Sum('amount'))['amount__sum'] or 0
        total_expenses = Transaction.objects.filter(user=request.user, type='expense').aggregate(Sum('amount'))['amount__sum'] or 0

        # Convert to float
        total_income = float(total_income) if total_income else 0.0
        total_expenses = float(total_expenses) if total_expenses else 0.0

        # Test user preferences
        user_preference, created = UserPreference.objects.get_or_create(
            user=request.user,
            defaults={'currency': 'USD', 'theme': 'light'}
        )

        test_results = {
            'database_connection': 'OK',
            'transactions_count': transactions_count,
            'budgets_count': budgets_count,
            'loans_count': loans_count,
            'total_income': total_income,
            'total_expenses': total_expenses,
            'user_preferences': 'OK',
            'currency': user_preference.currency,
            'theme': user_preference.theme,
            'decimal_conversion': 'OK',
            'message': 'All backend functionality is working correctly!'
        }

        return render(request, 'tracker/test.html', {'test_results': test_results})
    except Exception as e:
        return render(request, 'tracker/test.html', {
            'error': str(e),
            'message': 'Backend test failed!'
        })

@login_required
def api_docs(request):
    """API documentation page"""
    return render(request, 'tracker/api_docs.html')

@login_required
def loan_list(request):
    try:
        # Update loan statuses first
        loans = Loan.objects.filter(user=request.user)
        for loan in loans:
            loan.update_status()

        # Get updated loans
        loans = Loan.objects.filter(user=request.user).order_by('-start_date')

        # Calculate comprehensive statistics
        active_loans = loans.filter(status='active')
        overdue_loans = loans.filter(status='overdue')
        paid_loans = loans.filter(status='paid')
        partially_paid_loans = loans.filter(status='partially_paid')

        # Money lent (given) statistics
        loans_given_active = loans.filter(loan_type='given', status__in=['active', 'overdue', 'partially_paid'])
        total_given = loans_given_active.aggregate(Sum('amount'))['amount__sum'] or 0
        total_given_with_interest = sum(float(loan.total_amount_with_interest) for loan in loans_given_active)
        total_received_back = loans_given_active.aggregate(Sum('paid_amount'))['paid_amount__sum'] or 0

        # Money borrowed (taken) statistics
        loans_taken_active = loans.filter(loan_type='taken', status__in=['active', 'overdue', 'partially_paid'])
        total_taken = loans_taken_active.aggregate(Sum('amount'))['amount__sum'] or 0
        total_taken_with_interest = sum(float(loan.total_amount_with_interest) for loan in loans_taken_active)
        total_paid_back = loans_taken_active.aggregate(Sum('paid_amount'))['paid_amount__sum'] or 0

        # Interest calculations
        total_interest_earning = sum(float(loan.interest_earned_or_owed) for loan in loans_given_active)
        total_interest_owing = sum(float(loan.interest_earned_or_owed) for loan in loans_taken_active)

        # Convert Decimal to float for template
        total_given = float(total_given) if total_given else 0.0
        total_taken = float(total_taken) if total_taken else 0.0
        total_received_back = float(total_received_back) if total_received_back else 0.0
        total_paid_back = float(total_paid_back) if total_paid_back else 0.0

        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/loan_list.html', {
            'loans': loans,
            'active_count': active_loans.count(),
            'overdue_count': overdue_loans.count(),
            'paid_count': paid_loans.count(),
            'partially_paid_count': partially_paid_loans.count(),
            'total_given': total_given,
            'total_taken': total_taken,
            'total_given_with_interest': total_given_with_interest,
            'total_taken_with_interest': total_taken_with_interest,
            'total_received_back': total_received_back,
            'total_paid_back': total_paid_back,
            'total_interest_earning': total_interest_earning,
            'total_interest_owing': total_interest_owing,
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Error in loan_list view: {str(e)}")
        logger.error(traceback.format_exc())
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def add_loan(request):
    try:
        if request.method == 'POST':
            form = LoanForm(request.POST)
            if form.is_valid():
                loan = form.save(commit=False)
                loan.user = request.user
                loan.save()
                messages.success(request, "Loan added successfully!")
                return redirect('loan_list')
        else:
            form = LoanForm(initial={'start_date': timezone.now().date()})

        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/loan_form.html', {
            'form': form,
            'title': 'Add Loan',
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Add loan error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def edit_loan(request, pk):
    try:
        loan = get_object_or_404(Loan, id=pk, user=request.user)

        if request.method == 'POST':
            form = LoanForm(request.POST, instance=loan)
            if form.is_valid():
                form.save()
                messages.success(request, "Loan updated successfully!")
                return redirect('loan_list')
        else:
            form = LoanForm(instance=loan)

        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/loan_form.html', {
            'form': form,
            'title': 'Edit Loan',
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Edit loan error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def delete_loan(request, pk):
    try:
        loan = get_object_or_404(Loan, id=pk, user=request.user)

        if request.method == 'POST':
            loan.delete()
            messages.success(request, "Loan deleted successfully!")
            return redirect('loan_list')

        return render(request, 'tracker/confirm_delete.html', {'object': loan, 'type': 'Loan'})
    except Exception as e:
        logger.error(f"Delete loan error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

@login_required
def mark_loan_paid(request, pk):
    try:
        loan = get_object_or_404(Loan, id=pk, user=request.user)

        if request.method == 'POST':
            loan.status = 'paid'
            loan.save()
            messages.success(request, "Loan marked as paid!")
            return redirect('loan_list')

        return render(request, 'tracker/confirm_delete.html', {
            'object': loan,
            'type': 'Mark Loan as Paid',
            'action': 'mark as paid'
        })
    except Exception as e:
        logger.error(f"Mark loan paid error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})


@login_required
def loan_detail(request, pk):
    """Detailed view of a loan with payment history"""
    try:
        loan = get_object_or_404(Loan, id=pk, user=request.user)
        loan.update_status()  # Update status before displaying

        # Get payment history
        payments = loan.payments.all().order_by('-payment_date')

        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/loan_detail.html', {
            'loan': loan,
            'payments': payments,
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Loan detail error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})


@login_required
def add_loan_payment(request, pk):
    """Add a payment to a loan"""
    try:
        loan = get_object_or_404(Loan, id=pk, user=request.user)

        if request.method == 'POST':
            from .forms import LoanPaymentForm
            form = LoanPaymentForm(request.POST, loan=loan)
            if form.is_valid():
                payment = form.save(commit=False)
                payment.loan = loan
                payment.save()

                # Update loan paid amount and status
                loan.add_payment(payment.amount)

                messages.success(request, f"Payment of ${payment.amount} added successfully!")
                return redirect('loan_detail', pk=loan.id)
        else:
            from .forms import LoanPaymentForm
            form = LoanPaymentForm(loan=loan)

        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/loan_payment_form.html', {
            'form': form,
            'loan': loan,
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Add loan payment error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})


@login_required
def loan_analytics(request):
    """Comprehensive loan analytics and insights"""
    try:
        loans = Loan.objects.filter(user=request.user)

        # Update all loan statuses
        for loan in loans:
            loan.update_status()

        # Calculate analytics
        total_loans = loans.count()
        active_loans = loans.filter(status__in=['active', 'overdue', 'partially_paid'])

        # Money flow analysis
        total_lent = loans.filter(loan_type='given').aggregate(Sum('amount'))['amount__sum'] or 0
        total_borrowed = loans.filter(loan_type='taken').aggregate(Sum('amount'))['amount__sum'] or 0

        # Interest analysis
        total_interest_earned = sum(float(loan.interest_earned_or_owed) for loan in loans.filter(loan_type='given'))
        total_interest_owed = sum(float(loan.interest_earned_or_owed) for loan in loans.filter(loan_type='taken'))

        # Risk analysis
        overdue_loans = loans.filter(status='overdue')
        high_priority_loans = loans.filter(priority='high')

        # Monthly trends (last 12 months)
        monthly_data = []
        for i in range(12):
            month_date = timezone.now().date().replace(day=1) - timedelta(days=30*i)
            month_loans = loans.filter(start_date__year=month_date.year, start_date__month=month_date.month)

            monthly_data.append({
                'month': month_date.strftime('%B %Y'),
                'loans_given': month_loans.filter(loan_type='given').count(),
                'loans_taken': month_loans.filter(loan_type='taken').count(),
                'amount_given': float(month_loans.filter(loan_type='given').aggregate(Sum('amount'))['amount__sum'] or 0),
                'amount_taken': float(month_loans.filter(loan_type='taken').aggregate(Sum('amount'))['amount__sum'] or 0),
            })

        monthly_data.reverse()  # Show oldest to newest

        # Calculate completed loans
        completed_loans_count = loans.filter(status='paid').count()

        currency_symbol = get_user_currency_symbol(request)
        return render(request, 'tracker/loan_analytics.html', {
            'total_loans': total_loans,
            'active_loans_count': active_loans.count(),
            'overdue_loans_count': overdue_loans.count(),
            'completed_loans_count': completed_loans_count,
            'high_priority_count': high_priority_loans.count(),
            'total_lent': float(total_lent),
            'total_borrowed': float(total_borrowed),
            'total_interest_earned': total_interest_earned,
            'total_interest_owed': total_interest_owed,
            'monthly_data': monthly_data,
            'overdue_loans': overdue_loans,
            'high_priority_loans': high_priority_loans,
            'currency_symbol': currency_symbol
        })
    except Exception as e:
        logger.error(f"Loan analytics error: {str(e)}")
        messages.error(request, f"An error occurred: {str(e)}")
        return render(request, 'tracker/error.html', {'error': str(e)})

# API Views for Preferences
@login_required
def api_get_preferences(request):
    """API endpoint to get user preferences"""
    try:
        user_preference, created = UserPreference.objects.get_or_create(
            user=request.user,
            defaults={'currency': 'USD', 'theme': 'light'}
        )

        data = {
            'currency': user_preference.currency,
            'currency_symbol': user_preference.get_currency_symbol(),
            'theme': user_preference.theme,
            'user': request.user.username
        }

        return JsonResponse(data)
    except Exception as e:
        logger.error(f"API get preferences error: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def api_update_preferences(request):
    """API endpoint to update user preferences"""
    if request.method != 'POST':
        return JsonResponse({'error': 'POST method required'}, status=405)

    try:
        import json
        data = json.loads(request.body)

        user_preference, created = UserPreference.objects.get_or_create(
            user=request.user,
            defaults={'currency': 'USD', 'theme': 'light'}
        )

        # Update fields if provided
        if 'currency' in data:
            user_preference.currency = data['currency']
        if 'theme' in data:
            user_preference.theme = data['theme']

        user_preference.save()

        response_data = {
            'success': True,
            'currency': user_preference.currency,
            'currency_symbol': user_preference.get_currency_symbol(),
            'theme': user_preference.theme,
            'message': 'Preferences updated successfully'
        }

        return JsonResponse(response_data)
    except Exception as e:
        logger.error(f"API update preferences error: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def api_get_dashboard_data(request):
    """API endpoint to get dashboard data"""
    try:
        # Get current month transactions
        current_month = datetime.now().month
        current_year = datetime.now().year

        transactions = Transaction.objects.filter(
            user=request.user,
            date__month=current_month,
            date__year=current_year
        )

        # Calculate totals
        income = transactions.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
        expenses = transactions.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
        balance = income - expenses

        # Get active loans
        active_loans = Loan.objects.filter(user=request.user, status='active')
        loans_given = active_loans.filter(loan_type='given').aggregate(Sum('amount'))['amount__sum'] or 0
        loans_taken = active_loans.filter(loan_type='taken').aggregate(Sum('amount'))['amount__sum'] or 0

        # Get user currency symbol
        currency_symbol = get_user_currency_symbol(request)

        data = {
            'income': float(income),
            'expenses': float(expenses),
            'balance': float(balance),
            'loans_given': float(loans_given),
            'loans_taken': float(loans_taken),
            'currency_symbol': currency_symbol,
            'month': current_month,
            'year': current_year
        }

        return JsonResponse(data)
    except Exception as e:
        logger.error(f"API dashboard data error: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def api_transaction_count(request):
    """API endpoint for total transaction count"""
    try:
        total_count = Transaction.objects.filter(user=request.user).count()
        return JsonResponse({
            'total_count': total_count
        })
    except Exception as e:
        logger.error(f"API transaction count error: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def upload_transactions_csv(request):
    """Upload transactions from CSV file"""
    if request.method == 'POST' and request.FILES.get('csv_file'):
        try:
            csv_file = request.FILES['csv_file']

            # Validate file type
            if not csv_file.name.endswith('.csv'):
                messages.error(request, "Please upload a CSV file.")
                return redirect('transaction_list')

            # Read CSV file
            file_data = csv_file.read().decode('utf-8')
            csv_reader = csv.DictReader(file_data.splitlines())

            success_count = 0
            error_count = 0
            errors = []

            for row_num, row in enumerate(csv_reader, start=2):  # Start from 2 (header is row 1)
                try:
                    # Expected columns: Type, Amount, Description, Date, Month
                    transaction_type = row.get('Type', '').lower().strip()
                    amount = float(row.get('Amount', 0))
                    description = row.get('Description', '').strip()
                    date_str = row.get('Date', '').strip()

                    # Validate required fields
                    if not transaction_type or transaction_type not in ['income', 'expense']:
                        errors.append(f"Row {row_num}: Invalid transaction type '{transaction_type}'. Must be 'income' or 'expense'.")
                        error_count += 1
                        continue

                    if amount <= 0:
                        errors.append(f"Row {row_num}: Invalid amount '{amount}'. Must be greater than 0.")
                        error_count += 1
                        continue

                    if not description:
                        errors.append(f"Row {row_num}: Description is required.")
                        error_count += 1
                        continue

                    # Parse date
                    try:
                        if date_str:
                            # Try different date formats
                            for date_format in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y', '%Y/%m/%d']:
                                try:
                                    transaction_date = datetime.strptime(date_str, date_format).date()
                                    break
                                except ValueError:
                                    continue
                            else:
                                raise ValueError("Invalid date format")
                        else:
                            transaction_date = timezone.now().date()
                    except ValueError:
                        errors.append(f"Row {row_num}: Invalid date format '{date_str}'. Use YYYY-MM-DD, MM/DD/YYYY, or DD/MM/YYYY.")
                        error_count += 1
                        continue

                    # Set default category based on type
                    if transaction_type == 'income':
                        category = 'other_income'
                    else:
                        category = 'other_expense'

                    # Create transaction
                    Transaction.objects.create(
                        user=request.user,
                        type=transaction_type,
                        amount=amount,
                        category=category,
                        description=description,
                        date=transaction_date
                    )

                    success_count += 1

                except Exception as e:
                    errors.append(f"Row {row_num}: {str(e)}")
                    error_count += 1

            # Show results
            if success_count > 0:
                messages.success(request, f"Successfully imported {success_count} transactions.")

            if error_count > 0:
                error_msg = f"Failed to import {error_count} transactions. Errors:\n" + "\n".join(errors[:5])
                if len(errors) > 5:
                    error_msg += f"\n... and {len(errors) - 5} more errors."
                messages.error(request, error_msg)

            return redirect('transaction_list')

        except Exception as e:
            logger.error(f"CSV upload error: {str(e)}")
            messages.error(request, f"Error processing CSV file: {str(e)}")
            return redirect('transaction_list')

    return render(request, 'tracker/upload_csv.html')

def logout_view(request):
    """Custom logout view with message"""
    from django.contrib.auth import logout
    logout(request)
    messages.success(request, "You have been successfully logged out.")
    return redirect('login')

