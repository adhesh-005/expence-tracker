from django.contrib import admin
from .models import Transaction, Budget, UserPreference, Loan

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('user', 'date', 'type', 'category', 'amount', 'description')
    list_filter = ('user', 'type', 'category')
    search_fields = ('description',)
    date_hierarchy = 'date'

@admin.register(Budget)
class BudgetAdmin(admin.ModelAdmin):
    list_display = ('user', 'category', 'amount', 'month', 'year')
    list_filter = ('user', 'month', 'year')
    search_fields = ('category',)

@admin.register(UserPreference)
class UserPreferenceAdmin(admin.ModelAdmin):
    list_display = ('user', 'currency', 'theme')

@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = ('user', 'loan_type', 'person', 'amount', 'start_date', 'due_date', 'status')
    list_filter = ('user', 'loan_type', 'status')
    search_fields = ('person', 'description')
    date_hierarchy = 'start_date'

