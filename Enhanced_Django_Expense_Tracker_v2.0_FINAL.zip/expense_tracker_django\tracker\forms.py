from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Transaction, Budget, UserPreference, Loan, LoanPayment

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user

class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['type', 'amount', 'category', 'description', 'date']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.TextInput(attrs={'placeholder': 'Enter description'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['type'].widget.attrs.update({'class': 'form-select'})
        self.fields['category'].widget.attrs.update({'class': 'form-select'})
        self.fields['amount'].widget.attrs.update({'class': 'form-control'})
        self.fields['description'].widget.attrs.update({'class': 'form-control'})
        self.fields['date'].widget.attrs.update({'class': 'form-control'})

class BudgetForm(forms.ModelForm):
    class Meta:
        model = Budget
        fields = ['category', 'amount', 'month', 'year']
        widgets = {
            'year': forms.NumberInput(attrs={'min': 2000, 'max': 2100}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].widget.attrs.update({'class': 'form-select'})
        self.fields['amount'].widget.attrs.update({'class': 'form-control'})
        self.fields['month'].widget.attrs.update({'class': 'form-select'})
        self.fields['year'].widget.attrs.update({'class': 'form-control'})

class UserPreferenceForm(forms.ModelForm):
    class Meta:
        model = UserPreference
        fields = ['currency', 'theme']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['currency'].widget.attrs.update({'class': 'form-select'})
        self.fields['theme'].widget.attrs.update({'class': 'form-select'})

class LoanForm(forms.ModelForm):
    class Meta:
        model = Loan
        fields = [
            'loan_type', 'amount', 'person', 'person_contact', 'description',
            'start_date', 'due_date', 'interest_rate', 'priority',
            'reminder_enabled', 'reminder_days_before'
        ]
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'due_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Additional notes about the loan...'}),
            'person_contact': forms.TextInput(attrs={'placeholder': 'Phone number or email'}),
            'interest_rate': forms.NumberInput(attrs={'step': '0.01', 'min': '0', 'max': '100'}),
            'reminder_days_before': forms.NumberInput(attrs={'min': '1', 'max': '365'}),
        }
        labels = {
            'loan_type': 'Loan Type',
            'amount': 'Loan Amount',
            'person': 'Person Name',
            'person_contact': 'Contact Information',
            'description': 'Description/Notes',
            'start_date': 'Start Date',
            'due_date': 'Due Date',
            'interest_rate': 'Interest Rate (% per year)',
            'priority': 'Priority Level',
            'reminder_enabled': 'Enable Reminders',
            'reminder_days_before': 'Reminder Days Before Due',
        }
        help_texts = {
            'amount': 'Enter the loan amount without currency symbol',
            'interest_rate': 'Annual interest rate (0 for no interest)',
            'reminder_days_before': 'How many days before due date to send reminder',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Add CSS classes
        self.fields['loan_type'].widget.attrs.update({'class': 'form-select'})
        self.fields['amount'].widget.attrs.update({'class': 'form-control'})
        self.fields['person'].widget.attrs.update({'class': 'form-control'})
        self.fields['person_contact'].widget.attrs.update({'class': 'form-control'})
        self.fields['description'].widget.attrs.update({'class': 'form-control'})
        self.fields['start_date'].widget.attrs.update({'class': 'form-control'})
        self.fields['due_date'].widget.attrs.update({'class': 'form-control'})
        self.fields['interest_rate'].widget.attrs.update({'class': 'form-control'})
        self.fields['priority'].widget.attrs.update({'class': 'form-select'})
        self.fields['reminder_enabled'].widget.attrs.update({'class': 'form-check-input'})
        self.fields['reminder_days_before'].widget.attrs.update({'class': 'form-control'})

        # Set default values for new loans
        if not self.instance.pk:
            from django.utils import timezone
            self.fields['start_date'].initial = timezone.now().date()
            self.fields['reminder_enabled'].initial = True
            self.fields['reminder_days_before'].initial = 7

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount and amount <= 0:
            raise forms.ValidationError("Loan amount must be greater than zero.")
        return amount

    def clean_interest_rate(self):
        rate = self.cleaned_data.get('interest_rate')
        if rate and (rate < 0 or rate > 100):
            raise forms.ValidationError("Interest rate must be between 0 and 100 percent.")
        return rate

    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        due_date = cleaned_data.get('due_date')

        if start_date and due_date and due_date <= start_date:
            raise forms.ValidationError("Due date must be after start date.")

        return cleaned_data


class LoanPaymentForm(forms.ModelForm):
    class Meta:
        model = LoanPayment
        fields = ['amount', 'payment_date', 'notes']
        widgets = {
            'payment_date': forms.DateInput(attrs={'type': 'date'}),
            'notes': forms.Textarea(attrs={'rows': 2, 'placeholder': 'Optional payment notes...'}),
            'amount': forms.NumberInput(attrs={'step': '0.01', 'min': '0.01'}),
        }
        labels = {
            'amount': 'Payment Amount',
            'payment_date': 'Payment Date',
            'notes': 'Payment Notes',
        }

    def __init__(self, *args, **kwargs):
        self.loan = kwargs.pop('loan', None)
        super().__init__(*args, **kwargs)

        # Add CSS classes
        self.fields['amount'].widget.attrs.update({'class': 'form-control'})
        self.fields['payment_date'].widget.attrs.update({'class': 'form-control'})
        self.fields['notes'].widget.attrs.update({'class': 'form-control'})

        # Set default payment date
        if not self.instance.pk:
            from django.utils import timezone
            self.fields['payment_date'].initial = timezone.now().date()

        # Add remaining amount info if loan is provided
        if self.loan:
            remaining = float(self.loan.remaining_amount)
            self.fields['amount'].help_text = f"Remaining amount: ${remaining:.2f}"
            self.fields['amount'].widget.attrs['max'] = str(remaining)

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount and amount <= 0:
            raise forms.ValidationError("Payment amount must be greater than zero.")

        if self.loan and amount > self.loan.remaining_amount:
            raise forms.ValidationError(f"Payment amount cannot exceed remaining amount of ${self.loan.remaining_amount:.2f}")

        return amount


