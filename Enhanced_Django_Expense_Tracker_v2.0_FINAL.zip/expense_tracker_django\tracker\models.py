from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class UserPreference(models.Model):
    CURRENCY_CHOICES = [
        ('USD', 'US Dollar ($)'),
        ('EUR', 'Euro (€)'),
        ('GBP', 'British Pound (£)'),
        ('INR', 'Indian Rupee (₹)'),
        ('JPY', 'Japanese Yen (¥)'),
        ('CNY', 'Chinese Yuan (¥)'),
        ('CAD', 'Canadian Dollar ($)'),
        ('AUD', 'Australian Dollar ($)'),
    ]
    
    THEME_CHOICES = [
        ('light', 'Light'),
        ('dark', 'Dark'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES, default='USD')
    theme = models.CharField(max_length=10, choices=THEME_CHOICES, default='light')
    
    def __str__(self):
        return f"{self.user.username}'s preferences"
    
    def get_currency_symbol(self):
        currency_symbols = {
            'USD': '$',
            'EUR': '€',
            'GBP': '£',
            'INR': '₹',
            'JPY': '¥',
            'CNY': '¥',
            'CAD': '$',
            'AUD': '$',
        }
        return currency_symbols.get(self.currency, '$')

class Transaction(models.Model):
    TYPE_CHOICES = [
        ('income', 'Income'),
        ('expense', 'Expense'),
    ]
    
    CATEGORY_CHOICES = [
        # Income categories
        ('salary', 'Salary'),
        ('business', 'Business'),
        ('investment', 'Investment'),
        ('gift', 'Gift'),
        ('other_income', 'Other Income'),
        
        # Expense categories
        ('food', 'Food & Dining'),
        ('shopping', 'Shopping'),
        ('housing', 'Housing'),
        ('transportation', 'Transportation'),
        ('entertainment', 'Entertainment'),
        ('utilities', 'Utilities'),
        ('healthcare', 'Healthcare'),
        ('education', 'Education'),
        ('personal', 'Personal Care'),
        ('travel', 'Travel'),
        ('debt', 'Debt Payment'),
        ('other_expense', 'Other Expense'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    description = models.CharField(max_length=255)
    date = models.DateField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.get_type_display()} - {self.amount} - {self.date}"

class Budget(models.Model):
    MONTH_CHOICES = [
        ('January', 'January'),
        ('February', 'February'),
        ('March', 'March'),
        ('April', 'April'),
        ('May', 'May'),
        ('June', 'June'),
        ('July', 'July'),
        ('August', 'August'),
        ('September', 'September'),
        ('October', 'October'),
        ('November', 'November'),
        ('December', 'December'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    category = models.CharField(max_length=20, choices=Transaction.CATEGORY_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    month = models.CharField(max_length=10, choices=MONTH_CHOICES)
    year = models.IntegerField()
    
    class Meta:
        unique_together = ('user', 'category', 'month', 'year')
    
    def __str__(self):
        return f"{self.month} {self.year} - {self.get_category_display()} - {self.amount}"

class Loan(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('paid', 'Paid'),
        ('partially_paid', 'Partially Paid'),
        ('overdue', 'Overdue'),
        ('defaulted', 'Defaulted'),
    ]

    TYPE_CHOICES = [
        ('given', 'Money Lent'),
        ('taken', 'Money Borrowed'),
    ]

    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    loan_type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    amount = models.DecimalField(max_digits=12, decimal_places=2, help_text="Original loan amount")
    person = models.CharField(max_length=100, help_text="Name of the person")
    person_contact = models.CharField(max_length=20, blank=True, null=True, help_text="Phone number or email")
    description = models.TextField(blank=True, null=True, help_text="Additional notes about the loan")

    # Dates
    start_date = models.DateField(default=timezone.now, help_text="Date when loan was given/taken")
    due_date = models.DateField(help_text="Expected repayment date")
    paid_date = models.DateField(blank=True, null=True, help_text="Date when loan was fully paid")

    # Interest and Payment Tracking
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, help_text="Annual interest rate (%)")
    paid_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.00, help_text="Amount paid so far")

    # Status and Priority
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='active')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')

    # Reminders
    reminder_enabled = models.BooleanField(default=True, help_text="Enable payment reminders")
    reminder_days_before = models.IntegerField(default=7, help_text="Days before due date to send reminder")
    last_reminder_sent = models.DateField(blank=True, null=True)

    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-start_date', '-created_at']
        indexes = [
            models.Index(fields=['user', 'status']),
            models.Index(fields=['due_date']),
            models.Index(fields=['loan_type']),
        ]

    def __str__(self):
        return f"{self.get_loan_type_display()} - {self.person} - ${self.amount}"

    @property
    def remaining_amount(self):
        """Calculate remaining amount to be paid"""
        return self.total_amount_with_interest - self.paid_amount

    @property
    def total_amount_with_interest(self):
        """Calculate total amount including interest"""
        if self.interest_rate == 0:
            return self.amount

        # Calculate simple interest
        days_elapsed = (timezone.now().date() - self.start_date).days
        years_elapsed = days_elapsed / 365.25
        interest_amount = self.amount * (self.interest_rate / 100) * years_elapsed
        return self.amount + interest_amount

    @property
    def interest_earned_or_owed(self):
        """Calculate interest earned (for given loans) or owed (for taken loans)"""
        return self.total_amount_with_interest - self.amount

    @property
    def days_until_due(self):
        """Calculate days until due date"""
        return (self.due_date - timezone.now().date()).days

    @property
    def is_overdue(self):
        """Check if loan is overdue"""
        return timezone.now().date() > self.due_date and self.status == 'active'

    @property
    def payment_progress_percentage(self):
        """Calculate payment progress as percentage"""
        if self.total_amount_with_interest == 0:
            return 0
        return min((self.paid_amount / self.total_amount_with_interest) * 100, 100)

    @property
    def status_color(self):
        """Get Bootstrap color class for status"""
        colors = {
            'active': 'primary',
            'paid': 'success',
            'partially_paid': 'warning',
            'overdue': 'danger',
            'defaulted': 'dark'
        }
        return colors.get(self.status, 'secondary')

    @property
    def priority_color(self):
        """Get Bootstrap color class for priority"""
        colors = {
            'low': 'success',
            'medium': 'warning',
            'high': 'danger',
            'urgent': 'dark'
        }
        return colors.get(self.priority, 'secondary')

    def update_status(self):
        """Automatically update status based on payment and due date"""
        if self.paid_amount >= self.total_amount_with_interest:
            self.status = 'paid'
            if not self.paid_date:
                self.paid_date = timezone.now().date()
        elif self.paid_amount > 0:
            self.status = 'partially_paid'
        elif self.is_overdue:
            self.status = 'overdue'
        else:
            self.status = 'active'

        self.save()

    def add_payment(self, amount):
        """Add a payment to this loan"""
        self.paid_amount += amount
        self.update_status()

        # Create payment record
        LoanPayment.objects.create(
            loan=self,
            amount=amount,
            payment_date=timezone.now().date()
        )


class LoanPayment(models.Model):
    """Track individual payments made towards a loan"""
    loan = models.ForeignKey(Loan, on_delete=models.CASCADE, related_name='payments')
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_date = models.DateField(default=timezone.now)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-payment_date', '-created_at']

    def __str__(self):
        return f"Payment of ${self.amount} for {self.loan.person} on {self.payment_date}"


