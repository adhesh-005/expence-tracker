from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('register/', views.register, name='register'),
    path('profile/', views.profile, name='profile'),
    
    # Transaction URLs
    path('transactions/', views.transaction_list, name='transaction_list'),
    path('transactions/add/', views.add_transaction, name='add_transaction'),
    path('transactions/edit/<int:pk>/', views.edit_transaction, name='edit_transaction'),
    path('transactions/delete/<int:pk>/', views.delete_transaction, name='delete_transaction'),
    
    # Budget URLs
    path('budgets/', views.budget_list, name='budget_list'),
    path('budgets/add/', views.add_budget, name='add_budget'),
    path('budgets/edit/<int:pk>/', views.edit_budget, name='edit_budget'),
    path('budgets/delete/<int:pk>/', views.delete_budget, name='delete_budget'),
    
    # Loan URLs
    path('loans/', views.loan_list, name='loan_list'),
    path('loans/add/', views.add_loan, name='add_loan'),
    path('loans/edit/<int:pk>/', views.edit_loan, name='edit_loan'),
    path('loans/delete/<int:pk>/', views.delete_loan, name='delete_loan'),
    path('loans/mark-paid/<int:pk>/', views.mark_loan_paid, name='mark_loan_paid'),
    path('loans/detail/<int:pk>/', views.loan_detail, name='loan_detail'),
    path('loans/payment/<int:pk>/', views.add_loan_payment, name='add_loan_payment'),
    path('loans/analytics/', views.loan_analytics, name='loan_analytics'),
    
    # Reports and analysis
    path('reports/', views.reports, name='reports'),
    path('spending-analysis/', views.spending_analysis, name='spending_analysis'),
    path('advanced-analysis/', views.advanced_analysis_report, name='advanced_analysis_report'),
    path('export-transactions/', views.export_transactions, name='export_transactions'),
    path('export-financial-report/', views.export_financial_report, name='export_financial_report'),
    path('export-pdf-report/', views.export_pdf_report, name='export_pdf_report'),
    path('upload-transactions/', views.upload_transactions_csv, name='upload_transactions_csv'),

    # Test view
    path('test/', views.test_view, name='test_view'),

    # API endpoints
    path('api/docs/', views.api_docs, name='api_docs'),
    path('api/preferences/', views.api_get_preferences, name='api_get_preferences'),
    path('api/preferences/update/', views.api_update_preferences, name='api_update_preferences'),
    path('api/dashboard/', views.api_get_dashboard_data, name='api_dashboard_data'),
    path('api/transactions/count/', views.api_transaction_count, name='api_transaction_count'),
]

